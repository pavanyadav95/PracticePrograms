package streamapi;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class EmpMain {
    public static void main(String[] args) {
        Map<String, Emp> map = new HashMap<>();
        map.put("B", new Emp("Pavan", 27));
        map.put("C", new Emp("Sourav", 24));
        map.put("A", new Emp("Mahesh", 30));
        map.put("d", new Emp("Amol", 32));
        map.put("e", new Emp("Atul", 35));

        LinkedHashMap<String, Emp> sortedMap = map.entrySet().stream()
                .sorted(Map.Entry.comparingByValue(Comparator.comparing(Emp::getAge).reversed()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
                        (e1, e2) -> e2, LinkedHashMap::new));
        sortedMap.forEach((k, v) -> System.out.print( "." + k + " " + v.getName() + " " +v.getAge() ));

        List<Emp> emps = new ArrayList<>();
        emps.add(new Emp("pavan", 27));
        emps.add(new Emp("Atul", 35));
        emps.add(new Emp("Amol", 32));
        emps.add(new Emp("Mahesh", 30));
        List<Emp> list = emps.stream().sorted((e1,e2) -> e2.getAge() - e1.getAge()).collect(Collectors.toList());
        System.out.println();
        list.forEach(e -> System.out.print(e.getName() + " " + e.getAge() + " || "));
    }
}
