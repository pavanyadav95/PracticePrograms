package Blocks;

public class Block {
    {
        System.out.println("IIB");
    }
    static {
        System.out.println("static");
    }
    public Block() {
        System.out.println("Constructor");
    }

    public static void main(String[] args) {
        Block b =  new Block();
    }
}
