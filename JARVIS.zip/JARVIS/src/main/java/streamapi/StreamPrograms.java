package streamapi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.stream.Collectors;

import clone.Employee;

public class StreamPrograms {
    public static void main(String[] args) {
        ArrayList<String> arrayList = new ArrayList<>();
        List<String> list1 = new ArrayList<>();
        list1.add("pavan");
        list1.add("sourav");
        list1.add("mahesh");
        list1.add("amol");
        list1.add("atul");
        list1.add("aaa");
        list1.add("aaa");
        List<String> list2 = list1.stream()
                .filter(s -> s.startsWith("a"))
                .map(String::toUpperCase)
                .sorted(Comparator.reverseOrder())
                .distinct()
                .skip(0)
                .limit(3)
                .collect(Collectors.toList());
        System.out.println(list1);
        System.out.println(list2);
        boolean b = list1.stream()
                .noneMatch(s -> s.contains("a"));
        //.anyMatch(s -> s.contains("a"));
        //.allMatch(s -> s.contains("a"));
        System.out.println("match : " + b);
        long l = list1.stream()
                .filter(s -> s.startsWith("a"))
                .count();
        System.out.println("count  : " + l);

        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee("pavan", "yadav1"));
        employees.add(new Employee("sourav", "yadav4"));
        employees.add(new Employee("mahesh", "yadav3"));
        employees.add(new Employee("amol", "yadav2"));
        System.out.println("Emp : " + employees);

        employees.stream()
                .sorted(Comparator.comparing(Employee::getSurName).reversed())
                .forEach(emp -> System.out.println(emp.getSurName()));

        List<String> l1 = new ArrayList<>();
        System.out.println("empty list size : " + l1.size());
        l1.add("p1");
        List<String> l2 = Collections.unmodifiableList(l1);
        System.out.println("unmodifiable list : " + l2);
        l1.add("p2");
        System.out.println("unmodifiable list after modification: " + l2);

        Map<String, Integer> map = new HashMap<>();
        System.out.println("size : " + map.size());
        map.put("aaa", 1);
        System.out.println("size : " + map.size());
        map.put("bbb", 2);
        map.put("ccc", 3);
        map.put("ddd", 4);
        map.put("eee", 5);

        List<String> listGroupBy = Arrays.asList("Pavan", "Sourav", "Amol", "Mahesh", "Atul", "Sourav", "Mahesh", "Pavan", "Sourav", "Amol", "Pavan", "Pavan");
        Map<String, Long> stringLongMap = listGroupBy.stream().collect(
                Collectors.groupingBy(
                        Function.identity(), Collectors.counting()
                )
        );
        System.out.println("listGroupBy : " + stringLongMap);
        Map<String, Long> stringLongMap1 = new TreeMap<>(stringLongMap);
        List<String> list5 = new ArrayList<>();
        list5.add("a");
        list5.add("a");
        list5.add("b");
        list5.add("c");
        list5.add("c");
        Set<String> set = new HashSet<>(list5);
        System.out.println("set : " + set);

        list5.stream().distinct().forEach(System.out::print);
        System.out.println();
        list5.stream().collect(Collectors.toSet());
        new HashSet<>(list5);
        Set<String> set2 = new HashSet<>();
        Set<String> set4 =list5.stream()
                .filter(q -> !set2.add(q))
                .collect(Collectors.toSet());
        System.out.println("set4 : " + set4);
        Set<String> set3 =  list5.stream()
                .filter(q -> Collections.frequency(list5,q) > 1)
                .collect(Collectors.toSet());
        System.out.println("set3 : " + set3);
    }
}
