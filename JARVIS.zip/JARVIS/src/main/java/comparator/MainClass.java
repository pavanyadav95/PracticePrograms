package comparator;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class MainClass {
    public static void main(String[] args) {
        List<Emp> emps = new ArrayList<>();
        emps.add(new Emp("pavan", 27));
        emps.add(new Emp("Atul", 35));
        emps.add(new Emp("Amol", 32));
        emps.add(new Emp("Mahesh", 30));
        System.out.println("original list");
        emps.forEach(e -> System.out.print(" , " + e.getName() + " " + e.getAge()));
        System.out.println();
        List<Emp> list = emps.stream().sorted(new SortByName()).collect(Collectors.toList());
        System.out.println(".......................................");
        System.out.println("original list");
        list.forEach(e -> System.out.println(e.getName() + " " + e.getAge()));

        list = sortByComparator(emps, new SortByName());
        list.forEach(e -> System.out.println(e.getName() + " " + e.getAge()));
        System.out.println(".......................................");

        list = sortByComparator(emps, new SortByAge());
        list.forEach(e -> System.out.println(e.getName() + " " + e.getAge()));
        System.out.println(".......................................");

        List<Emp> list2 = emps.stream().sorted((e1, e2) -> e1.getName().compareTo(e2.getName())).collect(Collectors.toList());
        list2.forEach(e -> System.out.println(e.getName() + " " + e.getAge()));
        System.out.println(".......................................");

        List<Emp> list3 = emps.stream().sorted((e1, e2) -> e1.getAge() - e2.getAge()).collect(Collectors.toList());
        list3.forEach(e -> System.out.println(e.getName() + " " + e.getAge()));
    }

    private static List<Emp> sortByComparator(List<Emp> list, Comparator<Emp> empComparator) {
        return list.stream().sorted(empComparator).collect(Collectors.toList());
    }

    private static List<Emp> sortByNormal(List<Emp> list, Comparator<Emp> empComparator) {
        return list.stream().sorted((e1, e2) -> e1.getName().compareTo(e2.getName())).collect(Collectors.toList());
    }
}
