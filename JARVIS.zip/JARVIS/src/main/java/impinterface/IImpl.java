package impinterface;

public class IImpl implements I2, I1 {
    @Override
    public String getName(String name) {
        return name;
    }

    @Override
    public String getName2(String name) {
        return I1.super.getName2(name);
    }

    @Override
    public void getName3(String name) {
        I2.super.getName3(name);
    }

    public static void main(String[] args) {
        I1 i = new IImpl();
        System.out.println(i.getName("pavan"));
        System.out.println(i.getName2("Pavan"));
    }
}
