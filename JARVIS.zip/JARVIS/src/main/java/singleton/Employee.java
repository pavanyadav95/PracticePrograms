package singleton;

class Test {
    public int x, y;
}

public class Employee implements Cloneable {
    String name;
    Test t = new Test();

    public Integer getA() {
        return a;
    }

    public void setA(Integer a) {
        this.a = a;
    }

    Integer a;

    @Override
    protected Employee clone() throws CloneNotSupportedException {
        return (Employee) super.clone();
    }

    public Employee() {

    }

    public Employee(String name, Integer a, String surName) {
        this.name = name;
        this.a = a;
        this.surName = surName;
    }

    public Employee(String name, String surName) {
        this.name = name;
        this.surName = surName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurName() {
        return surName;
    }

    public void setSurName(String surName) {
        this.surName = surName;
    }

    String surName;
}