package singleton;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Constructor;

public class SingletonMain implements Cloneable {

    static void test() {
        int a = 10;
        System.out.println(a);
    }

    public static void main(String[] args) throws IOException, ClassNotFoundException, CloneNotSupportedException {
        Singleton s1 = Singleton.getInstance();
        s1.str = "pavan111";
        Singleton s2 = null;
        Singleton s3 = null;
        Singleton s4 = null;
        Singleton s5 = null;
        System.out.println("Hashcode : " + s1.hashCode());
        System.out.println(System.getenv());
        Singleton singleton2 = Singleton.getInstance();
        System.out.println("Hashcode : " + singleton2.hashCode());

        //reflection API
        try {
            Constructor constructor = Singleton.class.getDeclaredConstructor();
            constructor.setAccessible(true);
            s2 = (Singleton) constructor.newInstance();
            System.out.println("s1 hashcode : " + s1.hashCode());
            System.out.println("s2 hashcode : " + s2.hashCode());
        } catch (Exception e) {
        }

        //Serialization
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream("pavan.txt"));
        objectOutputStream.writeObject(s1);
        objectOutputStream.close();

        ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream("pavan.txt"));
        s3 = (Singleton) objectInputStream.readObject();
        System.out.println("s3 hashcode : " + s3.hashCode() + " , " + s3.str);

        //clone
        s4 = (Singleton) s1.clone();
        System.out.println("s4 hashcode : " + s4.hashCode());
    }
}
