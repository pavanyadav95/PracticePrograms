package palindrome;

public class Palindrome {
    public static void main(String[] args) {
        int no = 153;
        int temp;
        int sum = 0;
        while (no > 0) {
            temp = no % 10; //3
            System.out.println(temp * temp * temp);
            sum = sum + (temp * temp * temp);
            no = no / 10;   //12
        }
        System.out.println("sum : " + sum);
    }
}
