package fibonacy;

public class Fibonacy {
    public static void main(String[] args) {
        int no = 50;
        int pre = 0;
        int current = 1;
        int next;
        while (current < no){
            next = pre + current;
            System.out.print(next + " ");
            pre = current;
            current = next;
        }
    }
}
