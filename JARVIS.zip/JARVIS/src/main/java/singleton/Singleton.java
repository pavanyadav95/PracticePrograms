package singleton;

import java.io.Serializable;

public class Singleton extends Employee implements Serializable, Cloneable {
    private static Singleton singleton;

    public String str = "pavan";

    private Singleton() {
        super(null, null);
        // avoid reflection
        if (singleton != null)
            throw new RuntimeException("you can't");
    }

    // avoid serialization
    protected Object readResolve() {
        return singleton;
    }

    // avoid clone
    public Employee clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException("don't clone");
    }

    public static Singleton getInstance() {
        synchronized (Singleton.class) {
            if (singleton == null) {
                singleton = new Singleton();
            }
        }
        return singleton;
    }
}
