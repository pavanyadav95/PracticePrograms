package impinterface;

public interface I4 {
    public default void getData() {

    }
}
