package marker;

public class MarkerImpl implements TestMarker {

    public static boolean checkMarker(Object o) {
        if (o instanceof TestMarker) {
            return true;
        }
        return false;
    }
}
