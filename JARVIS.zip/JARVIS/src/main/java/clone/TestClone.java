package clone;

class Address {
    String city;

    public Address(String city) {
        this.city = city;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}

public class TestClone implements Cloneable {
    private String name;
    private Address address;

    public TestClone(String name, Address address) {
        this.name = name;
        this.address = address;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "clone.TestClone{" +
                "name='" + name + '\'' +
                ", address=" + address.city +
                '}';
    }

/*
    @Override
    protected Object clone() throws CloneNotSupportedException {
        return new clone.TestClone(name, new clone.Address(address.city));
    }
*/

    public static void main(String[] args) throws CloneNotSupportedException {
        TestClone testClone = new TestClone("Pavan", new Address("Pune"));
        TestClone testClone1 = (TestClone) testClone.clone();
        testClone1.getAddress().setCity("Dighanchi");
        System.out.println("test 1 : " + testClone + " , " + testClone.hashCode());
        System.out.println("test 1 : " + testClone1 + " , " + testClone1.hashCode());
        Double d1 = 1.0012;
        Double d2 = Double.valueOf(1.0012);
        System.out.println(" hashcode : " + d1.hashCode());
        System.out.println(" hashcode : " + d2.hashCode());
    }
}
