package impinterface;

public class TestClass {
    public static void main(String[] args) {
        I3 i3 =  new I3() {
            @Override
            public String getValue1(String str) {
                return str;
            }

            @Override
            public String getValue2(String str) {
                return str;
            }
        };
        System.out.println(i3.getValue1("A"));
        System.out.println(i3.getValue2("B"));
    }
}
