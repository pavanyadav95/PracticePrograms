package impinterface;

public interface I2  {

    public String getName(String name);

    public default String getName2(String name) {
        System.out.println("impinterface.I2");
        return name;
    }

    public default void getName3(String name) {
        System.out.println("impinterface.I2 3");
    }
}
