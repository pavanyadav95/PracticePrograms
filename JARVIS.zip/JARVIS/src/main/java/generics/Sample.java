package generics;

import java.lang.reflect.InvocationTargetException;

class Test<T> {
    private T t;

    public Test(T t) {
        this.t = t;
    }

    public T getObject() {
        return this.t;
    }
}

public class Sample {
    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        System.out.println("finalize called");
    }

    public static void main(String[] args) throws InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        Test<Integer> t1 = new Test<>(10);
        System.out.println("integer : " + t1.getObject());

        Test<String> t2 = new Test<>("Pavan");
        System.out.println("string : " + t2.getObject());

        //System.gc();
        t1 = null;
        t2 = null;
        Runtime.getRuntime().gc();
        //System.out.println("str : " + t2.getObject());
    }


}
