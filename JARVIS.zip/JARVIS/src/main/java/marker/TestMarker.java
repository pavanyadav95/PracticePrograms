package marker;

public interface TestMarker {
}
