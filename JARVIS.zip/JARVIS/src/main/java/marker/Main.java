package marker;

public class Main {
    public static void main(String[] args) {
        System.out.println(" marker : " + MarkerImpl.checkMarker(new MarkerImpl()));
    }
}
