package StringSamples;

import org.apache.commons.lang3.StringUtils;

public class StringSamples {
    public static void main(String[] args) {
        String str = "I love my country and I am Pavan";
        long l = StringUtils.countMatches(str, "a");
        System.out.println("duplicate count : " + l);
        char ch[] = str.toCharArray();
        char ch2[] = str.toCharArray();
        for (int i = 0; i < ch.length; i++) {
            //System.out.println("ch : " + ch[i] + "  " + StringUtils.countMatches(str, ch[i]));
        }

        // remove repeated characters and print duplication count
        for (int i = 0; i < ch.length; i++) {
            int count = 1;
            for (int j = i + 1; j < ch.length; j++) {
                if (ch[i] == ch[j]) {
                    count++;
                    ch[j] = 0;
                }
            }
            if (ch[i] > 1 && ch[i] != '0' && ch[i] != ' ') {
                System.out.print(ch[i] + " " + count + " , ");
            }
        }

        //reverse string
        System.out.println();
        for (int i = str.length() - 1; i >= 0; i--) {
            System.out.print(ch2[i]);
        }

        //reverse the words of string
        int end = str.length();
        System.out.println();
        for (int i = str.length() - 1; i >= 0; i--) {
            if (ch2[i] == ' ') {
                print(ch2, i + 1, end);
                end = i;
            }
            if (i == 0)
                print(ch2, i, end);
        }

        //string to char array
        char ch3[] = new char[str.length()];
        for (int i = 0; i < str.length(); i++) {
            ch3[i] = str.charAt(i);
        }
        System.out.println();
        for (int i = 0; i < str.length(); i++)
            System.out.print(ch3[i]);
    }

    static void print(char ch2[], int a, int b) {
        for (int i = a; i < b; i++)
            System.out.print(ch2[i]);
        System.out.print(" ");
    }
}
