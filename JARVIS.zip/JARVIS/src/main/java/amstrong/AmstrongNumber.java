package amstrong;

public class AmstrongNumber {
    public static void main(String[] args) {
        int no = 123;
        int sum = 0;
        int temp = no;
        int t;
        System.out.println(no % 10);
        System.out.println(no / 10);
        while (no > 0) {
            t = no % 10;
            sum = (sum * 10) + t;
            no = no / 10;
        }
        if (temp == sum) {
            System.out.println(sum + " is amstrong no");
        }
    }
}
