package immutable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ImmutableClass {
    private final String name;

    private final List<String> list = new ArrayList<>();        // non immutable

    private final List<String> list2 = List.of("a","b");        // immutable - we cannot modify it from outside

    private final List<String> list3 = Arrays.asList("a","b");  // immutable - we cannot modify it from outside

    public ImmutableClass(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public List<String> getList() {
        list.add("a");
        list.add("c");
        list.add("d");
        return list;
    }

    public List<String> getList2() {
        return list2;
    }

    public List<String> getList3() {
        return list3;
    }
}
