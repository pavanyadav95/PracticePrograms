package lambda;

public class LambdaMain {
    public static void main(String[] args) {
        FunctionalInterface functionalInterface = (str) -> {
            System.out.println("str : " + str);
            return str;
        };
        System.out.println(functionalInterface.getData("pavan"));
    }
}
