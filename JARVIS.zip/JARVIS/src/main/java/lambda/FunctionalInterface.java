package lambda;

@java.lang.FunctionalInterface
public interface FunctionalInterface {
    public String getData(String str);
}
