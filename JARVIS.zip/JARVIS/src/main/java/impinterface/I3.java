package impinterface;

public interface I3 {
    String getValue1(String str);
    String getValue2(String str);
}
