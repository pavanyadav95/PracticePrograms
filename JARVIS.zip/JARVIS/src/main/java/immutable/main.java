package immutable;

import java.util.List;

public class main {
    public static void main(String[] args) {
        ImmutableClass immutableClass = new ImmutableClass("Pavan");
        System.out.println("1 : " + immutableClass.getList());
        immutableClass.getList().add("q");
        immutableClass.getList().remove("a");
        System.out.println("2 : " + immutableClass.getList());

        List<String> list = immutableClass.getList2();
        list.add("11");

        immutableClass.getList2().add("r");
        System.out.println("3 : " + immutableClass.getList2());

        immutableClass.getList3().add("t");
        System.out.println("4 : " + immutableClass.getList3());
    }
}
