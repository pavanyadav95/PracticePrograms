package streamapi;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Test {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        list.add("d");
        list.add("v");
        list.add("g");
        list.add("q");
        list.add("a");
        list.add("a");
        list.add("a1");
        List<String> list1 = list.stream()
                .filter(e -> e.startsWith("a"))
                .map(String::toUpperCase)
                .distinct()
                .collect(Collectors.toList());
        System.out.println(list1);

        Collections.reverse(list);

        Integer i1 = 200;
        Integer i2 = 200;
        System.out.println(i1 == i2);
        System.out.println(i1.equals(i2));
        List<Emp> empList = new ArrayList<>();
        empList.add(new Emp("sourav", 24));
        empList.add(new Emp("pavan", 27));
        List<String> list2 = empList.stream()
                .map(Emp::getName)
                .collect(Collectors.toList())
                .stream().sorted(Comparator.reverseOrder())
                .collect(Collectors.toList());
        System.out.println(" emp list : " + empList);
        System.out.println(" name list : " + list2);

        List<Emp> list3 = empList.stream().
                sorted(Comparator.comparing(Emp::getName).reversed()).
                collect(Collectors.toList());
        System.out.println(" rv emp list : " + list3);
    }
}
