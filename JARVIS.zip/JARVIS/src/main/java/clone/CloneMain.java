package clone;

import java.util.stream.IntStream;

import singleton.Singleton;

public class CloneMain extends Employee {
    public CloneMain(String name, String surName) {
        super(name, surName);
    }

    public static void main(String[] args) throws CloneNotSupportedException {
        Employee e1 = new Employee("Mahesh", 10, "Nikam");
        Employee e2 = (Employee) e1.clone();
        Singleton s1 = null;
        System.out.println("e1 name : " + e1.getA());
        System.out.println("e2 name : " + e2.getA());
        e2.setA(11);
        System.out.println("e1 name : " + e1.getA());
        System.out.println("e2 name : " + e2.getA());

        IntStream intStream = "pavan12k5kk".chars();
        intStream.forEach(s -> System.out.print(s + ", "));
    }
}
