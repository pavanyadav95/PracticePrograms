package array;

public class CommonElementsArray {
    public static void main(String[] args) {
        int[] arr1 = {1, 2, 4, 8, 4};
        int[] arr2 = {2, 4, 8};
        for (int i = 0; i < arr2.length; i++) {
            for (int j = 0; j < arr1.length; j++) {
                if (arr2[i] == arr1[j]) {
                    System.out.println(arr2[i]);
                    break;
                }
            }
        }
    }
}
