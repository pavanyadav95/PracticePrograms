package impinterface;

@FunctionalInterface
public interface I5 extends I4{
    public void test1();
}
